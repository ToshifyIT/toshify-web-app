#!/usr/bin/env node
/**
 * `npm run dev:full`
 * Levanta el servidor de API (server.js, puerto 3001) y el dev server de Vite
 * en un solo comando, y los baja juntos con Ctrl+C.
 *
 * Sirve para los módulos que dependen de /api/* (Drive, contratos, Intercom...).
 * La vista /hellosign NO lo necesita: su API va montada dentro del propio Vite
 * (ver el plugin `toshify-hellosign-dev-api` en vite.config.ts).
 */

import { spawn } from 'node:child_process';

const procesos = [];
let bajando = false;

function lanzar(nombre, comando, args, env = {}) {
  const child = spawn(comando, args, {
    stdio: 'inherit',
    env: { ...process.env, ...env },
    shell: process.platform === 'win32',
  });

  child.on('exit', (code, signal) => {
    if (bajando) return;
    console.log(`\n[dev:full] "${nombre}" terminó (code=${code} signal=${signal}). Bajando todo.`);
    bajarTodo(code ?? 1);
  });

  child.on('error', (err) => {
    console.error(`[dev:full] No se pudo iniciar "${nombre}":`, err.message);
    bajarTodo(1);
  });

  procesos.push(child);
  return child;
}

function bajarTodo(code = 0) {
  if (bajando) return;
  bajando = true;
  for (const child of procesos) {
    if (!child.killed) child.kill('SIGTERM');
  }
  setTimeout(() => process.exit(code), 300);
}

process.on('SIGINT', () => bajarTodo(0));
process.on('SIGTERM', () => bajarTodo(0));

console.log('[dev:full] Iniciando API (server.js :3001) + Vite...\n');
lanzar('api', process.execPath, ['server.js'], { PORT: '3001' });
lanzar('vite', 'npx', ['vite', '--mode', 'development']);
